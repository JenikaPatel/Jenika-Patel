#include "fun.h"
//#include <fun.h>

int square(int number) 
{
   return number * number;
}