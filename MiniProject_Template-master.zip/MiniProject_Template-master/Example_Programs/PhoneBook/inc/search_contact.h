/** 
* @file search_contact.h
*
*/

#ifndef __SEARCH_CONTACT_H__
#define __SEARCH_CONTACT_H__

#include "contact.h"

int search_contact(const char* name);

#endif  //__SEARCH_CONTACT_H__
