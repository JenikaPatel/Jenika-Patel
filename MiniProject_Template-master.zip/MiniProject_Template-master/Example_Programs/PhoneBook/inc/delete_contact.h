/** 
* @file delete_contact.h
*
*/

#ifndef __DELETE_CONTACT_H__
#define __DELETE_CONTACT_H__

#include "contact.h"

int delete_contact(const char* name);

#endif  //__DELETE_CONTACT_H__
