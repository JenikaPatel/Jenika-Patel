/** 
* @file display_contact.h
*
*/

#ifndef __DISPLAY_CONTACT_H__
#define __DISPLAY_CONTACT_H__

#include "contact.h"

int display_contact(void);

#endif  //__DISPLAY_CONTACT_H__
